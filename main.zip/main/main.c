#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include "cJSON.h"
#include "controlWIFI.h"
#include "driver/gpio.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "freertos/FreeRTOS.h"
#include "freertos/projdefs.h"
#include "freertos/task.h"
#include "hal/gpio_types.h"
#include "sdkconfig.h"
#include "controlThingsboard.h"
#include "esp_ota_ops.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "controlSPIFFS.h"
#include "controlRiego.h"
#include "controlAmbiental.h"
#include "controlTiempo.h"
#include "controlLuminosidad.h"

void regresoParticionActualizacion(){
	
	while(true){
	if(getActualizacion()==1){
    	esp_partition_iterator_t pi ;
    	const esp_partition_t* factory ;
    	esp_err_t err ;
    	pi = esp_partition_find ( ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_FACTORY, "factory" );
    	if ( pi == NULL ){
        	ESP_LOGE ("Partition", "Failed to find factory partition") ;
    	}else{
        	factory = esp_partition_get ( pi );
        	esp_partition_iterator_release ( pi );
        	err = esp_ota_set_boot_partition ( factory ); 
        	if (err != ESP_OK){
            	ESP_LOGE ("Partition", "Failed to set boot partition" ) ;
        	}else{
            	esp_restart() ;
        	}
       	}
	}
	
	retrasoRelativoMinutos(1);
	}
	
   
}

void app_main(void)
{
	
    iniciarAPSTA();
    iniciarMQTT();
    //iniciarSPIFFS();
    
    iniciarSTA();
    conectarWIFI("SBC", "SBCwifi$");
    
    
    xTaskCreate(controlAmbiental, "Control de temperatura, humedad, CO2 y presion", 4096, NULL, 8, NULL);
    xTaskCreate(controlLuminosidad, "Control de luminosidad", 4096, NULL, 5, NULL);
    xTaskCreate(controlRiego, "Control de riego", 2048, NULL, 7, NULL);
	xTaskCreate(controlOxigeno, "Control de oxigeno", 2048, NULL, 6, NULL);
	
	regresoParticionActualizacion();	
	
	
	
	
		
}
