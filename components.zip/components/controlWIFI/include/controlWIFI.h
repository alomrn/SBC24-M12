#include <stdbool.h>

void iniciarAPSTA();
void iniciarAP();
void iniciarSTA();
void conectarWIFI(const char* ssid, const char* password);
bool getEstadoConexionSTA();
void desconectarAPSTA();
void conectarAPSTA();