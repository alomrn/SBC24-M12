#include <stdio.h>
#include <string.h>
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_wifi_types_generic.h"
#include "esp_log.h"
#include "esp_http_server.h"
#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "controlThingsboard.h"
#include "nvs_flash.h"
#include "controlSPIFFS.h"

#define AP_SSID CONFIG_SSID
#define AP_PASS CONFIG_PASSWORD

#define TAGAP "Punto de acceso"
#define TAGSTA "Wifi"

bool CONECTADO = false;

const char* WEB = "<!DOCTYPE html>"
    "<html lang=\"es\">"
    "<head>"
    "<meta charset=\"UTF-8\">"
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
    "<title>Formulario de Conexión</title>"
    "<style>"
    "body {"
    "    font-family: Arial, sans-serif;"
    "    background-color: #f0f4f8;"
    "    display: flex;"
    "    justify-content: center;"
    "    align-items: center;"
    "    height: 100vh;"
    "    margin: 0;"
    "}"
    ".container {"
    "    background-color: #ffffff;"
    "    border-radius: 8px;"
    "    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);"
    "    padding: 20px;"
    "    width: 300px;"
    "    text-align: center;"
    "}"
    "h2 {"
    "    color: #333;"
    "    font-size: 20px;"
    "    margin-bottom: 20px;"
    "}"
    ".input-group {"
    "    margin-bottom: 15px;"
    "}"
    "label {"
    "    display: block;"
    "    margin-bottom: 5px;"
    "    color: #555;"
    "}"
    "input[type=\"text\"], input[type=\"password\"] {"
    "    width: 90%;"
    "    max-width: 250px;"
    "    padding: 8px;"
    "    border: 1px solid #ddd;"
    "    border-radius: 4px;"
    "    font-size: 14px;"
    "}"
    "input[type=\"submit\"] {"
    "    background-color: #5cb85c;"
    "    color: white;"
    "    padding: 10px;"
    "    border: none;"
    "    border-radius: 4px;"
    "    cursor: pointer;"
    "    font-size: 16px;"
    "}"
    "input[type=\"submit\"]:hover {"
    "    background-color: #4cae4c;"
    "}"
    "</style>"
    "</head>"
    "<body>"
    "<div class=\"container\">"
    "<h2>Conexión Wi-Fi</h2>"
    "<form action=\"/connect\" method=\"post\">"
    "<div class=\"input-group\">"
    "<label for=\"ssid\">SSID:</label>"
    "<input type=\"text\" id=\"ssid\" name=\"ssid\" placeholder=\"Introduce el SSID\" required>"
    "</div>"
    "<div class=\"input-group\">"
    "<label for=\"password\">Contraseña:</label>"
    "<input type=\"password\" id=\"password\" name=\"password\" placeholder=\"Introduce la contraseña\" required>"
    "</div>"
    "<input type=\"submit\" value=\"Conectar\">"
    "</form>"
    "</div>"
    "</body>"
    "</html>";

void iniciarSTA();
void conectarWIFI(const char* ssid, const char* password);

esp_err_t preProcesamientoWeb(httpd_req_t *req) {
    httpd_resp_set_type(req, "text/html");
    return httpd_resp_send(req, WEB, strlen (WEB));
}

// Handler para recibir el formulario
esp_err_t postProcesamientoWeb(httpd_req_t *req) {
    char buffer[100];
    int ret;

    // Leer el cuerpo de la solicitud
    ret = httpd_req_recv(req, buffer, sizeof(buffer) - 1); // Leer de una sola vez
    if (ret <= 0) {
        return ESP_FAIL; // Error en la lectura
    }
    buffer[ret] = '\0';

    // Procesar los datos
    char ssid[32];
    char password[64];

    // Extraer los datos del formulario
    sscanf(buffer, "ssid=%31[^&]&password=%63s", ssid, password);

    ESP_LOGI(TAGAP, "SSID: %s", ssid);
    ESP_LOGI(TAGAP, "Password: %s", password);
    
    guardarCredencialesArchivo(ssid, password);

    // Responder al cliente
    const char resp[] = "La ESP32 va a intentar conectarse al wifi insertado";
    httpd_resp_send(req, resp, strlen(resp));
    
    vTaskDelay(500 / portTICK_PERIOD_MS);
    
    esp_restart();
     

    
    return ESP_OK;
}

httpd_handle_t iniciarServidorWeb(void) {
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();

    httpd_uri_t pre_uri = {
        .uri = "/",
        .method = HTTP_GET,
        .handler = preProcesamientoWeb,
        .user_ctx = NULL
    };

    httpd_uri_t post_uri = {
        .uri = "/connect",
        .method = HTTP_POST,
        .handler = postProcesamientoWeb,
        .user_ctx = NULL
    };

    // Iniciar el servidor
    httpd_handle_t server = NULL;
    if (httpd_start(&server, &config) == ESP_OK) {
        httpd_register_uri_handler(server, &pre_uri);
        httpd_register_uri_handler(server, &post_uri);
    }
    return server;
}

void setEstadoConexionSTA(bool estado){
	CONECTADO = estado;
}

bool getEstadoConexionSTA(){
	return CONECTADO;
}

void eventosAP(void* arg, esp_event_base_t event_base,
                               int32_t event_id, void* event_data) {	
								   						   
		if(event_base == WIFI_EVENT){
			if(event_id == WIFI_EVENT_AP_START){
            	ESP_LOGI(TAGAP, "Punto de acceso iniciado");
            }else if(event_id == WIFI_EVENT_AP_START) {
            	ESP_LOGI(TAGAP, "Punto de acceso iniciado");
        	} else if(event_id == WIFI_EVENT_AP_STOP) {
            	ESP_LOGI(TAGAP, "Punto de acceso detenido");
        	} else if(event_id == WIFI_EVENT_AP_STACONNECTED) {
            	ESP_LOGI(TAGAP, "Un dispositivo se ha conectado al AP");
        	} else if(event_id == WIFI_EVENT_AP_STADISCONNECTED) {
            	ESP_LOGI(TAGAP, "Un dispositivo se ha desconectado del AP");
        	}
		}						   
}

void eventosSTA(void* arg, esp_event_base_t event_base,
                               int32_t event_id, void* event_data) {
								   
        if (event_base == WIFI_EVENT) {
            if (event_id == WIFI_EVENT_STA_START) {
                esp_wifi_connect();
            } else if (event_id == WIFI_EVENT_STA_DISCONNECTED) {
                printf("Conexion con intento fallida\n");
                setEstadoConexionSTA(false);
            }
        } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
			setEstadoConexionSTA(true);
            ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
            ESP_LOGI(TAGSTA, "Got IP Address: " IPSTR, IP2STR(&event->ip_info.ip));
            conectarMQTT();
        }
}


void iniciarAP(){
	
    esp_netif_create_default_wifi_ap();
    
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    esp_event_handler_instance_t instance_any_id;
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &eventosAP,
                                                        NULL,
                                                        &instance_any_id));

    wifi_config_t wifi_config = {
        .ap = {
            .ssid = AP_SSID,
            .ssid_len = strlen(AP_SSID),
            .channel = 1,
            .password = AP_PASS,
            .max_connection = 4,
            .authmode = WIFI_AUTH_WPA_WPA2_PSK
        },
    };
    if (strlen(AP_PASS) == 0) {
        wifi_config.ap.authmode = WIFI_AUTH_OPEN;
    }

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
    iniciarServidorWeb();
}

void desconectarAPSTA(){
	esp_wifi_stop();
}

void conectarAPSTA(){
	esp_wifi_start();
}

void conectarWIFI(const char* ssid, const char* password) {
	
	esp_wifi_stop();

    wifi_config_t wifi_config = {};
    strncpy((char*)wifi_config.sta.ssid, ssid, sizeof(wifi_config.sta.ssid));
    strncpy((char*)wifi_config.sta.password, password, sizeof(wifi_config.sta.password));
    
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    
    ESP_ERROR_CHECK(esp_wifi_start());
}

void iniciarSTA(){
    
    esp_netif_create_default_wifi_sta();
    
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &eventosSTA, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &eventosSTA, NULL));
}

void iniciarAPSTA(){
	
	ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
}


