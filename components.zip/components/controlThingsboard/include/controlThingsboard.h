#include "cJSON.h"
void iniciarMQTT(void);
void publicarThingsboard(cJSON *datos);
void conectarMQTT();
void desconectarMQTT();
int getActualizacion();
