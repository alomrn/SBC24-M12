#include "controlThingsboard.h"
#include <stdio.h>
#include "driver/gpio.h"
#include "esp_log.h"
#include "hal/gpio_types.h"
#include "mqtt_client.h"
#include "cJSON.h"
#include "sdkconfig.h"
#include "controlRiego.h"
#include "controlLuminosidad.h"
#include "controlAmbiental.h"

#define URL CONFIG_URL
#define TOKEN CONFIG_TOKEN

#define TAG_TIEMPO_RIEGO CONFIG_TAG_TIEMPO_RIEGO
#define TAG_PERIODO_RIEGO CONFIG_TAG_PERIODO_RIEGO
#define TAG_TIEMPO_OXIGENADOR CONFIG_TAG_TIEMPO_OXIGENADOR
#define TAG_PERIODO_OXIGENADOR CONFIG_TAG_PERIODO_OXIGENADOR
#define TAG_PERIODO_ILUMINACION CONFIG_TAG_PERIODO_ILUMINACION
#define TAG_MODO CONFIG_TAG_MODO
#define TAG_UMBRAL_ACTIVACION CONFIG_TAG_UMBRAL_ACTIVACION
#define TAG_TIEMPO_VENTILADOR CONFIG_TAG_TIEMPO_VENTILADOR
#define TAG_PERIODO_AMBIENTAL CONFIG_TAG_PERIODO_AMBIENTAL
#define TAG_TEMP_ACTIVACION CONFIG_TAG_TEMP_ACTIVACION
#define TAG_ACTUALIZACION CONFIG_TAG_ACTUALIZACION


const char* TiposRecibidos[] = {
    TAG_TIEMPO_RIEGO,
    TAG_PERIODO_RIEGO,
    TAG_TIEMPO_OXIGENADOR,
    TAG_PERIODO_OXIGENADOR,
    TAG_PERIODO_ILUMINACION,
    TAG_MODO,
    TAG_UMBRAL_ACTIVACION,
    TAG_TIEMPO_VENTILADOR,
    TAG_PERIODO_AMBIENTAL,
    TAG_TEMP_ACTIVACION,
    TAG_ACTUALIZACION
};


const char *TAG = "mqtt_example";

int actualizacionPendiente = 0;

int getActualizacion(){
	return actualizacionPendiente;
}


esp_mqtt_client_handle_t client;

void procesarReciboDatos(const char* nombre, int valor) {
	
    for (int i = 0; i < 11; i++) {
        if (strcmp(nombre, TiposRecibidos[i]) == 0) {
            switch (i) {
                case 0:
                	
                    setTiempoRiego(valor);
                    break;
                case 1:
                	
                    setPeriodoRiego(valor);
                    break;
                case 2:
                	
                    setTiempoOxigenador(valor);
                    break;
                case 3:
                	
                    setPeriodoOxigenador(valor);
                    break;
                case 4:
                	
                    setPeriodoIluminacion(valor);
                    break;
                case 5:
                	
                	setModo(valor);
                	break;
                case 6:
                	
                	setUmbralActivacion(valor);
                	break;
                case 7:
                	
                	setTiempoVentilador(valor);
                	break;
                case 8:
                	
                	setPeriodoAmbiental(valor);
                	break;
                case 9:
           
                	setTemperaturaActivacion(valor);
                	break;
                case 10:
                	actualizacionPendiente = 1;
                	break;
                default:
                	printf("Mensaje recibido no valido\n");
                	break;
            }
        }
    }
}


void eventosMQTT(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data) {
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;
    esp_mqtt_client_handle_t client = event->client;

    switch (event->event_id) {
    case MQTT_EVENT_CONNECTED:
    
        ESP_LOGI(TAG, "MQTT Conectado");
        esp_mqtt_client_subscribe(client, "v1/devices/me/attributes", 0);
        break;

    case MQTT_EVENT_DISCONNECTED:
    
        ESP_LOGI(TAG, "MQTT desconectado");
        break;

    case MQTT_EVENT_SUBSCRIBED:
    
    	ESP_LOGI(TAG,"Suscripción exitosa al topic con ID: %d", event->msg_id);
        break;

    case MQTT_EVENT_UNSUBSCRIBED:
    	
    	ESP_LOGI(TAG,"Desuscripción exitosa al topic con ID: %d", event->msg_id);
        break;

    case MQTT_EVENT_PUBLISHED:
    	ESP_LOGI(TAG,"Mensaje publicado con ID: %d", event->msg_id);
        break;

    case MQTT_EVENT_DATA:
        ESP_LOGI(TAG,"Datos recibidos:");
        
        cJSON* datos = cJSON_Parse(event->data);
        cJSON* mensaje = datos->child;
        
        procesarReciboDatos(mensaje->string, mensaje->valueint);
    	
        break;

    case MQTT_EVENT_ERROR:
        printf("Error en MQTT: error_type=%d\n", event->error_handle->error_type);

        if (event->error_handle->error_type == MQTT_ERROR_TYPE_ESP_TLS) {
            printf("ESP-TLS error, código de error: 0x%x\n", event->error_handle->esp_tls_last_esp_err);
        } else if (event->error_handle->error_type == MQTT_ERROR_TYPE_CONNECTION_REFUSED) {
            printf("Conexión rechazada, código: 0x%x\n", event->error_handle->connect_return_code);
        } else {
            printf("Otro error en MQTT\n");
        }
        break;

    default:
        NULL;
        break;
    }
}

void publicarThingsboard(cJSON *datos) {
	
    char* mensaje = cJSON_Print(datos);
    esp_mqtt_client_publish(client, "v1/devices/me/telemetry", mensaje, 0, 1, 0);
    free(mensaje);
}

void desconectarMQTT(){
	esp_mqtt_client_stop(client);
}

void conectarMQTT(){
	esp_mqtt_client_start(client);
}

void iniciarMQTT(void)
{
    esp_mqtt_client_config_t mqtt_cfg = {
    .broker.address.uri = URL,  
    .credentials.username = TOKEN,  
};

    client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, eventosMQTT, NULL);
    
}

