#include "freertos/FreeRTOS.h"
// Función para mostrar la hora actual con una etiqueta personalizada
void mostrarTiempo(const char* etiqueta);

// Funciones para realizar retrasos relativos
void retrasoRelativoHoras(int horas);
void retrasoRelativoMinutos(int minutos);
void retrasoRelativoSegundos(int segundos);
void retrasoRelativoMilisegundos(int milisegundos);

TickType_t convertirHoras(int horas);
TickType_t convertirMinutos(int minutos);
TickType_t convertirSegundos(int segundos);
TickType_t convertirMilisegundos(int milisegundos);