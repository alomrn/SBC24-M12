#include <stdio.h>
#include "controlTiempo.h"
#include "time.h"
#include "freertos/FreeRTOS.h"

void mostrarTiempo(const char* etiqueta){
	
	struct tm *newtime;
   	time_t ltime;
	time(&ltime);
   	newtime = localtime(&ltime);
    printf("%s: %s",etiqueta, asctime(newtime));
    
}

TickType_t convertirHoras(int horas){
	return pdMS_TO_TICKS(horas*60*60*1000);
}

TickType_t convertirMinutos(int minutos){
	return pdMS_TO_TICKS(minutos*60*1000);
}

TickType_t convertirSegundos(int segundos){
	return pdMS_TO_TICKS(segundos*1000);
}

TickType_t convertirMilisegundos(int milisegundos){
	return pdMS_TO_TICKS(milisegundos);
}

void retrasoRelativoHoras(int horas){
	TickType_t milisegundos = convertirHoras(horas);
	vTaskDelay(milisegundos);
}

void retrasoRelativoMinutos(int minutos){
	TickType_t milisegundos = convertirMinutos(minutos);
	vTaskDelay(milisegundos);
}

void retrasoRelativoSegundos(int segundos){
	TickType_t milisegundos = convertirSegundos(segundos);
	vTaskDelay(milisegundos);
}

void retrasoRelativoMilisegundos(int milisegundos){
	
	vTaskDelay(convertirMilisegundos(milisegundos));
}