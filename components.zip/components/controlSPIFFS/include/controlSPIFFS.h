#include <stdbool.h>

void iniciarSPIFFS();
void guardarCredencialesArchivo(const char* ssid, const char* pass);
void comprobarCredencialesArchivo();
bool archivoCredencialesVacio();
void vaciarArchivoCredenciales();