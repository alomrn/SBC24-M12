#include <stdio.h>
#include "esp_spiffs.h"
#include "esp_log.h"
#include <string.h>
#include "controlWIFI.h"
#include "freertos/FreeRTOS.h"
#include "portmacro.h"
#include "controlSPIFFS.h"

#define TAG "spiffs"

#define RUTA CONFIG_PATH

void iniciarArchivoCredenciales(){
	
	FILE *file = fopen(RUTA, "r");
    
    if (file == NULL)
    {
		file = fopen(RUTA, "w");
		
    }else{

    	if(archivoCredencialesVacio())
    		iniciarAP();
    	else{
			iniciarSTA();
			comprobarCredencialesArchivo();
		}
	}
		
	fclose(file);
}

void iniciarSPIFFS(){
	
    esp_vfs_spiffs_conf_t config = {
        .base_path = "/spiffs",
        .partition_label = NULL,
        .max_files = 5,
        .format_if_mount_failed = true,
    };
    esp_vfs_spiffs_register(&config);
    
    iniciarArchivoCredenciales();
}


void guardarCredencialesArchivo(const char* ssid, const char* pass){
	
	ESP_LOGI (TAG, "Guardando credenciales en el archivo...");
	FILE *file = fopen(RUTA, "a");
	fprintf(file, "%s %s\n",ssid, pass);
	fclose(file);
	
}


void comprobarCredencialesArchivo(){
	
	FILE *file = fopen(RUTA, "r");
	
    char buffer[128];
    char ssid[64];
    char pass[64];
    
    while (fgets(buffer, sizeof(buffer), file) && !getEstadoConexionSTA()) {
        if (sscanf(buffer, "%62s %62s", ssid, pass) == 2) {
			 ESP_LOGI (TAG, "Probando credenciales SSID: %s...",ssid);
            conectarWIFI(ssid, pass);
            vTaskDelay(5000/ portTICK_PERIOD_MS);
         }
    }
    fclose(file);
	if(!getEstadoConexionSTA()){
		ESP_LOGI (TAG, "No existen credenciales validas");
		ESP_LOGI (TAG, "Volviendo al modo AP");
		desconectarAPSTA();
		iniciarAP();
	}  
}

bool archivoCredencialesVacio(){
	FILE *file = fopen(RUTA, "r");
    fseek(file, 0, SEEK_END);
    long size = ftell(file);

    fclose(file);

    return size == 0;
}

void vaciarArchivoCredenciales(){
	ESP_LOGI (TAG, "Vaciando archivo de credenciales");
	FILE *file = fopen(RUTA, "w");
	fclose(file);
}
