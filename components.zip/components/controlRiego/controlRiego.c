#include <stdio.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/adc.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "time.h"

#include "controlTiempo.h"
#include "controlThingsboard.h"


#define PIN_OXIGENO CONFIG_PIN_OXIGENADOR
#define PIN_RIEGO CONFIG_PIN_BOMBA_RIEGO
#define TAG CONFIG_TAG_NIVEL_AGUA

int periodoRiego = CONFIG_PERIODO_RIEGO;
int periodoOxigenador = CONFIG_PERIODO_OXIGENADOR;
int tiempoRiego = CONFIG_TIEMPO_RIEGO;
int tiempoOxigenador = CONFIG_TIEMPO_OXIGENADOR;

void setPeriodoRiego(int valor){
	if(tiempoRiego <= valor*60){
		periodoRiego = valor;
	}else printf("Valor no asignado : Periodo < tiempo\n");
}
void setPeriodoOxigenador(int valor){
	if(tiempoOxigenador <= valor*60){
		periodoOxigenador = valor;
	}else printf("Valor no asignado : Periodo < tiempo\n");
}
void setTiempoRiego(int valor){
	if(periodoRiego*60 >= valor){
		tiempoRiego = valor;
	}else printf("Valor no asignado : Periodo < tiempo\n");
	
}
void setTiempoOxigenador(int valor){
	if(periodoOxigenador*60 >= valor){
		tiempoOxigenador = valor;
	}else printf("Valor no asignado : Periodo < tiempo\n");
	
}


void enviarDatos(int valor){
	
	cJSON* datos = cJSON_CreateObject();
	
    cJSON_AddNumberToObject(datos, TAG ,valor);
    
    publicarThingsboard(datos);
    
    cJSON_Delete(datos);
	
}

void iniciarControlRiego(){
	
	gpio_set_direction(PIN_RIEGO, GPIO_MODE_OUTPUT);
 
    adc1_config_width(ADC_WIDTH_BIT_12); 
    adc1_config_channel_atten(ADC1_CHANNEL_4, ADC_ATTEN_DB_12);
    
    
}

void iniciarControlOxigenador(){
	gpio_set_direction(PIN_OXIGENO, GPIO_MODE_OUTPUT);
}

void iniciarOxigenador (){
	
	gpio_set_level(PIN_OXIGENO, 1);
	
	retrasoRelativoMinutos(tiempoOxigenador);
	
	gpio_set_level(PIN_OXIGENO, 0);
}


void iniciarRiego (){
	
	gpio_set_level(PIN_RIEGO, 1);
	
	retrasoRelativoSegundos(tiempoRiego);
	
	gpio_set_level(PIN_RIEGO, 0);
}

bool comprobarAgua (){  
    
    int nivelAgua = adc1_get_raw(ADC1_CHANNEL_4 );
    
    printf("Nivel del agua : %d\n", nivelAgua);
    
    return nivelAgua > 0;
}


void controlRiego(void *pvParameters){
	
	iniciarControlRiego();
	TickType_t tiempoInicio = xTaskGetTickCount();
    
	while(true){
		
		vTaskDelayUntil(&tiempoInicio, convertirMinutos(periodoRiego));
		
		
		mostrarTiempo("Riego");
   		
   		if(comprobarAgua()){
			   
			enviarDatos(100);
   			iniciarRiego();
   			
   		}
   		else enviarDatos(0);
   		
   		mostrarTiempo("--Riego");
   		
   		
	}
	
}

void controlOxigeno(void *pvParameters){
	
	iniciarControlOxigenador();  
	TickType_t tiempoInicio = xTaskGetTickCount(); 
	
	while(true){
		
		
		
		vTaskDelayUntil(&tiempoInicio, convertirMinutos(periodoOxigenador));
		
		mostrarTiempo("Oxigeno");
   		
   		if(comprobarAgua()){
			   
			enviarDatos(100);
   			iniciarOxigenador();
   			
   		}
   		else enviarDatos(0);
   		
   		mostrarTiempo("--Oxigeno");
   		
   		
	}
	
}