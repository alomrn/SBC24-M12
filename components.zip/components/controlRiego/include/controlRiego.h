void enviarDatos(int valor);
void controlRiego(void *pvParameters);
void controlOxigeno(void *pvParameters);
void setPeriodoRiego(int valor);
void setPeriodoOxigenador(int valor);
void setTiempoRiego(int valor);
void setTiempoOxigenador(int valor);