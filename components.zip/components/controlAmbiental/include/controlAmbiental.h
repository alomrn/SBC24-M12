void controlAmbiental(void *pvParameters);
void setPeriodoAmbiental(int valor);
void setTiempoVentilador(int valor);
void setTemperaturaActivacion(int valor);