#include <stdio.h>
#include "controlAmbiental.h"
#include "hal/gpio_types.h"
#include <stdio.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_system.h>
#include <bme680.h>
#include <string.h>
#include <driver/gpio.h>
#include "sdkconfig.h"
#include "time.h"
#include "controlThingsboard.h"
#include "controlTiempo.h"

#define PIN_VENTILADOR CONFIG_PIN_VENTILADOR
#define SCL CONFIG_PIN_SCL
#define SDA CONFIG_PIN_SDA

#define TAG_TEMP CONFIG_TAG_TEMP
#define TAG_HUM CONFIG_TAG_HUM
#define TAG_PRES CONFIG_TAG_PRES
#define TAG_GAS CONFIG_TAG_GAS


bme680_values_float_t valoresAmbientales;

int periodoAmbiental = CONFIG_PERIODO_AMBIENTAL;
int tiempoVentilador = CONFIG_TIEMPO_VENTILADOR;
int temperaturaActivacion = CONFIG_TEMPERATURA_ACTIVACION;

void enviarDatosAmbientales(){
	
	cJSON* datos = cJSON_CreateObject();
	
    cJSON_AddNumberToObject(datos, TAG_TEMP ,valoresAmbientales.temperature);
    cJSON_AddNumberToObject(datos, TAG_HUM ,valoresAmbientales.humidity);
    cJSON_AddNumberToObject(datos, TAG_PRES ,valoresAmbientales.pressure);
    cJSON_AddNumberToObject(datos, TAG_GAS ,valoresAmbientales.gas_resistance);
    
    publicarThingsboard(datos);
    
    cJSON_Delete(datos);
}

void setPeriodoAmbiental(int valor){
	
	if(valor*60 >= tiempoVentilador){
		periodoAmbiental = valor;
	}else printf("Periodo menor que tiempo de actuacion\n");
}

void setTiempoVentilador(int valor){
	
	if(valor <= periodoAmbiental*60){
		tiempoVentilador = valor;
	}else printf("Periodo menor que tiempo de actuacion\n");
	
}

void setTemperaturaActivacion(int valor){
    temperaturaActivacion = valor;
}

void iniciarControlAmbiental(){
   	
    bme680_t sensor;
    memset(&sensor, 0, sizeof(bme680_t));

    ESP_ERROR_CHECK(bme680_init_desc(&sensor, 0x76, 0, SDA, SCL));

    
    ESP_ERROR_CHECK(bme680_init_sensor(&sensor));

   
    uint32_t duration;
    bme680_get_measurement_duration(&sensor, &duration);

    TickType_t tiempoInicio = xTaskGetTickCount();
      
    while (true){
		
		vTaskDelayUntil(&tiempoInicio, convertirMinutos(periodoAmbiental));
		
		mostrarTiempo("Ambiente");
		
        if (bme680_force_measurement(&sensor) == ESP_OK){
            vTaskDelay(duration);
            if (bme680_get_results_float(&sensor, &valoresAmbientales) == ESP_OK){
                printf("Valores ambientales: %.2f C, %.2f %%, %.2f hPa, %.2f Ohm\n", valoresAmbientales.temperature, valoresAmbientales.humidity, valoresAmbientales.pressure, valoresAmbientales.gas_resistance);
                enviarDatosAmbientales();
            }
        }
            
      	if(valoresAmbientales.temperature > temperaturaActivacion){
		  gpio_set_level(PIN_VENTILADOR, 1);
          retrasoRelativoSegundos(tiempoVentilador);
          gpio_set_level(PIN_VENTILADOR, 0);
          }
          
         retrasoRelativoSegundos(tiempoVentilador);
	  	
	  	mostrarTiempo("--Ambiente");
        
    }
    
       
}


void controlAmbiental(void *pvParameters)
{
	
	gpio_set_direction(PIN_VENTILADOR, GPIO_MODE_OUTPUT);
	
	
	
    ESP_ERROR_CHECK(i2cdev_init());
    iniciarControlAmbiental();
}
