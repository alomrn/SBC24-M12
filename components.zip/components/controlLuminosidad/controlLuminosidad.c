#include <stdio.h>
#include "controlLuminosidad.h"
#include "driver/i2c.h"
#include "veml7700.h"
#include "controlThingsboard.h"
#include "controlTiempo.h"

#define SDA_PIN CONFIG_PIN_SDA
#define SCL_PIN CONFIG_PIN_SCL
#define I2C_MASTER_FREQ_HZ 1000
#define I2C_MASTER_NUM 0x00

#define PIN_ILUMINACION1 CONFIG_PIN_ILUMINACION1 
#define PIN_ILUMINACION2 CONFIG_PIN_ILUMINACION2 

#define TAG CONFIG_TAG_LUMENES

int modo  = CONFIG_MODO;
int periodoIluminacion = CONFIG_PERIODO_ILUMINACION;
int umbralActivacion = CONFIG_UMBRAL_ACTIVACION;


static double lux_als;

void setModo(int valor){
	modo = valor;
}

void setPeriodoIluminacion(int valor){
	periodoIluminacion = valor;
}

void setUmbralActivacion(int valor){
	umbralActivacion = valor;
}

void iniciarI2C(void)
{
	i2c_config_t conf;

	conf.mode = I2C_MODE_MASTER;
	conf.sda_io_num = SDA_PIN;
	conf.scl_io_num = SCL_PIN;
	conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
	conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
	conf.master.clk_speed = I2C_MASTER_FREQ_HZ;
	conf.clk_flags = 0;

	i2c_param_config(I2C_MASTER_NUM, &conf);
	i2c_driver_install(I2C_MASTER_NUM, I2C_MODE_MASTER, 0, 0, 0);
}

 void leerSensorLuz(void)
{ 
	veml7700_handle_t veml7700_dev;
	esp_err_t init_result = veml7700_initialize(&veml7700_dev, I2C_MASTER_NUM);
	if (init_result != ESP_OK) {
		return;
	}
	ESP_ERROR_CHECK( veml7700_read_als_lux_auto(veml7700_dev, &lux_als) );
	cJSON* datos = cJSON_CreateObject();
	cJSON_AddNumberToObject(datos, TAG ,lux_als);
	publicarThingsboard(datos);
	printf("Se ha detectado %0.4f lumenes \n", lux_als);
}

void controlLuminosidad(void *pvParameters)
{
	iniciarI2C();
	gpio_set_direction(PIN_ILUMINACION1, GPIO_MODE_OUTPUT);
	gpio_set_direction(PIN_ILUMINACION2, GPIO_MODE_OUTPUT);

	
    while (1) {
		
		retrasoRelativoMinutos(periodoIluminacion);
		
		mostrarTiempo("Luminosidad: ");
		
        leerSensorLuz();
        if(lux_als<umbralActivacion){
			switch (modo){
				case 0:
					gpio_set_level(PIN_ILUMINACION1, 1);
					gpio_set_level(PIN_ILUMINACION2, 0);
				break;
				case 1:
					gpio_set_level(PIN_ILUMINACION1, 0);
					gpio_set_level(PIN_ILUMINACION2, 1);
				break;
				case 2:
					gpio_set_level(PIN_ILUMINACION1, 1);
					gpio_set_level(PIN_ILUMINACION2, 1);
					
				break;
			}
			
			
		}
		else{
        	gpio_set_level(PIN_ILUMINACION1, 0);
        	gpio_set_level(PIN_ILUMINACION2, 0);
        	
    	}
        
        
        
    }
}