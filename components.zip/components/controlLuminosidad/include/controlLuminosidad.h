void controlLuminosidad(void *pvParameters);
void setModo(int valor);
void setPeriodoIluminacion(int valor);
void setUmbralActivacion(int valor);
